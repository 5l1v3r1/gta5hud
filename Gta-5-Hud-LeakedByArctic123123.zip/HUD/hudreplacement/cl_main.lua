local hideHUDElements = {
  ["DarkRP_HUD"] = false,
  ["DarkRP_EntityDisplay"] = false,
  ["DarkRP_ZombieInfo"] = false,
  ["DarkRP_LocalPlayerHUD"] = true,
  ["DarkRP_Agenda"] = false
}

hook.Add("HUDShouldDraw", "HideDefaultDarkRPHud", function(name)
	if hideHUDElements[name] or name == "CHudAmmo" or name ==	"CHudSecondaryAmmo" then return false end
end)

local HUD = {}

HUD.width = 250 // don't mess with these 
HUD.height = 175 
HUD.scrwidth = ScrW()
HUD.scrheight = ScrH()
HUD.mdata = ""
HUD.sdata = ""
HUD.jdata = ""

hook.Add("Think", "GetHUDVars", function() // workaround because of :getDarkRPVar returns nil at first
  HUD.mdata = LocalPlayer():getDarkRPVar("money")
  if not HUD.mdata then HUD.mdata = "" end
  
  HUD.sdata = LocalPlayer():getDarkRPVar("salary")
  if not HUD.sdata then HUD.sdata = "" end
  
  HUD.jdata = LocalPlayer():getDarkRPVar("job")
  if not HUD.jdata then HUD.jdata = "" end
  
  if (HUD.mdata ~= "" and HUD.sdata ~= "" and HUD.jdata ~= "") then
    hook.Remove("Think", "GetHUDVars")
  end
end)

hook.Add("DarkRPVarChanged", "UpdateHUDVars", function(ply, var, oldvar, newvalue)
  if ply == LocalPlayer() then
    if var == "money" then
      HUD.mdata = newvalue
    elseif var == "salary" then
      HUD.sdata = newvalue
    elseif var == "job" then
      HUD.jdata = newvalue
    end
  end
end)

local function RTS(font, text, XorY)
  surface.SetFont(font)
  local w, h = surface.GetTextSize(text)

  if XorY == true then
    return w
  else
    return h
  end
end

local function StartHUD()
  hook.Remove("HUDPaint", "DrawGTAHUD")

  local hud = vgui.Create("DPanel")
  hud:SetSize(HUD.width, HUD.height)
  hud:SetPos(25, HUD.scrheight - HUD.height - 10)
  hud:ParentToHUD()
  hud.Paint = function()
    surface.SetDrawColor(0, 0, 0, 245)
    surface.DrawRect(0, 0, HUD.width, HUD.height)
  end
  
  local health = vgui.Create("DPanel", hud)
  health:SetSize(119, 15)
  health:SetPos(5, HUD.height - 20)
  health.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():Health() ~= nil then
      local health = math.Clamp(LocalPlayer():Health(), 0, 100) * 1.19
      
      surface.SetDrawColor(80, 88, 63)
      surface.DrawRect(0, 0, 119, 15)
        
      surface.SetDrawColor(78, 119, 85)
      surface.DrawRect(0, 0, health, 15)
    end
  end
  
  local armor = vgui.Create("DPanel", hud)
  armor:SetSize(119, 15)
  armor:SetPos(126, HUD.height - 20)
  armor.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():Armor() ~= nil then
      local armor = math.Clamp(LocalPlayer():Armor(), 0, 100) * 1.19
      
      surface.SetDrawColor(21, 53, 66)
      surface.DrawRect(0, 0, 119, 15)
        
      surface.SetDrawColor(77, 146, 185)
      surface.DrawRect(0, 0, armor, 15)
    end
  end
  
  local overhead = vgui.Create("DPanel", hud)
  overhead:SetSize(240, 150)
  overhead:SetPos(5, 5)
  overhead.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():GetWeaponColor() ~= nil then
      local radius = 750
      local weaponcolor = LocalPlayer():GetWeaponColor()
        
      if !util.TraceLine(util.GetPlayerTrace(LocalPlayer(), Vector(0, 0, 90))).HitSky then
        radius = 100
      end

      local HeadCam = {} 
        
      if LocalPlayer() != nil then
        HeadCam.angles = Angle(90, LocalPlayer():EyeAngles().y, 0)
        HeadCam.origin = LocalPlayer():GetPos() + Vector(0, 0, radius)
      else
        HeadCam.angles = Angle(90, LocalPlayer():EyeAngles().y, 0)
        HeadCam.origin = LocalPlayer():GetPos() + Vector(0, 0, radius)
      end
            
      HeadCam.x = 30
      HeadCam.y = HUD.scrheight - HUD.height - 5
      HeadCam.w = 240
      HeadCam.h = 145
      
      local thingstohide = {}
        
      LocalPlayer():GetViewModel():SetNoDraw(true)
        
      LocalPlayer():SetWeaponColor(Vector(0, 0, 0))
      
      for k,v in pairs(ents.GetAll()) do
        if (v ~= LocalPlayer() and !v:IsVehicle() and !v:IsPlayer() and v:GetClass() ~= "prop_physics" and v ~= LocalPlayer():GetViewModel()) then
          table.insert(thingstohide, v)
          v:SetNoDraw(true)
        end
      end
        
        render.RenderView(HeadCam)
        
      for k,v in pairs(thingstohide) do
        v:SetNoDraw(false)
      end
          
      LocalPlayer():GetViewModel():SetNoDraw(false)
        
      LocalPlayer():SetWeaponColor(weaponcolor)
    end
  end
  
  local blip = vgui.Create("DImage", overhead)
  blip:SetSize(16, 16)
  blip:SetImage("materials/gtavhud/blip.png")
  blip:SetPos(115, 65)
  
  local money = vgui.Create("DLabel")
  money:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.mdata, true) + 15), 0)
  money:SetFont("MoneyFont")
  money:SetTextColor(Color(121, 147, 122))
  money:SetText("$ " .. HUD.mdata)
  money:SizeToContents()
  money.PerformLayout = function()
    money:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.mdata, true) + 15), 0)
    money:SetText("$ " .. HUD.mdata)
    money:SizeToContents()
  end
  money:ParentToHUD()
  
  local salary = vgui.Create("DLabel")
  salary:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.sdata, true) + 15), 50)
  salary:SetFont("MoneyFont")
  salary:SetTextColor(Color(121, 147, 122))
  salary:SetText("$ " .. HUD.sdata)
  salary:SizeToContents()
  salary.PerformLayout = function()
    salary:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.sdata, true) + 15), 50)
    salary:SetText("$ " .. HUD.sdata)
    salary:SizeToContents()
  end
  salary:ParentToHUD()
  
  local job = vgui.Create("DLabel")
  job:SetPos(ScrW() - (RTS("MoneyFont", HUD.jdata, true) + 15), 100)
  job:SetFont("MoneyFont")
  job:SetText(HUD.jdata)
  job:SizeToContents()
  job.PerformLayout = function()
    job:SetPos(ScrW() - (RTS("MoneyFont", HUD.jdata, true) + 15), 100)
    job:SetText("")
    job:SetText(HUD.jdata)
    job:SizeToContents()
  end
  job:ParentToHUD()
  
  local ammocount = vgui.Create("DLabel")
  ammocount:SetFont("MoneyFont")
  ammocount:SizeToContents()
  ammocount:SetText(LocalPlayer():GetActiveWeapon():Clip1() .. " / " .. LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType()))
  ammocount:SetPos(0, -200)
  ammocount.Think = function()
    if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then 
      local curmagazine = LocalPlayer():GetActiveWeapon():Clip1()
      local remmagazine = LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType())
        
      if LocalPlayer():GetActiveWeapon():Clip1() >= 0 then
        ammocount:SetPos(ScrW() - (RTS("MoneyFont", curmagazine .. " / " .. remmagazine, true) + 15), 150)
        ammocount:SetText(curmagazine .. " / " .. remmagazine)
        ammocount:SizeToContents()
      elseif LocalPlayer():GetActiveWeapon():Clip1() == -1 then
        ammocount:SetText("")
      end
    end
  end
  ammocount:ParentToHUD()
end

hook.Add("HUDPaint", "DrawGTAHUD", function()
  StartHUD()
end)