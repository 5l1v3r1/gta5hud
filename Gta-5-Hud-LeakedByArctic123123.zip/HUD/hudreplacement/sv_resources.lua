resource.AddFile("resource/fonts/pricedown bl.ttf")
resource.AddFile("materials/gtavhud/blip.png")